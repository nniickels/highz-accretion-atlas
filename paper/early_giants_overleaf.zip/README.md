Upload this ZIP to Overleaf as a new project.
Select main.tex as the main document and pdfLaTeX as the compiler.
The bibliography is embedded; no BibTeX step is needed.
The public draft PDF is available alongside this ZIP in the repository.
MANIFEST.json records source hashes and the matching draft PDF hash.
